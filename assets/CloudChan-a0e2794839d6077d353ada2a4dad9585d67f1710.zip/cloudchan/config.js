/**
 * CloudChan 配置文件
 * 版本：2.2.0
 */

const APP = {
    VERSION: '2.2.0',
    BUILD_TIME: '2026-01-17'
};

console.log(`CloudChan Config 已加载 - 版本: ${APP.VERSION}`);

export const CONFIG = {
    APP: { ...APP },

    // 后端接口配置
    API_DB_PROXY: '/api/db_proxy',
    API_GET_TOKEN: '/api/get_token',

    // Crust 官方直连上传接口
    CRUST_UPLOAD_API: 'https://gw.crustfiles.app/api/v0/add?pin=true',

    // 用于网关测速的测试文件内容标识（CID，约 1KB）
    TEST_CID: 'bafkreigh2akiscaildcqabsyg3dfr6chu3fgpregiymsck7e7aqa4s52zy',

    // IPFS 公共网关配置
    PUBLIC_GATEWAY_SOURCES: [
        'https://cdn.jsdelivr.net/gh/ipfs/public-gateway-checker@master/gateways.json',
        'https://raw.githubusercontent.com/ipfs/public-gateway-checker/master/gateways.json',
        'https://cdn.statically.io/gh/ipfs/public-gateway-checker/master/gateways.json',
        'https://ipfs.github.io/public-gateway-checker/gateways.json',
        'https://gcore.jsdelivr.net/gh/ipfs/public-gateway-checker@master/gateways.json',
        'https://fastly.jsdelivr.net/gh/ipfs/public-gateway-checker@master/gateways.json',
        'https://raw.githubusercontent.com/ipfs/ipfs-gateway/master/gateways.json',
        'https://cdn.jsdelivr.net/gh/ipfs/ipfs-gateway@main/gateways.json',
    ],

    // 默认精选网关列表
    DEFAULT_GATEWAYS: [
        // 国内友好网关（优先推荐）
        { name: 'Cloudflare-CN',  url: 'https://cf-ipfs.com/ipfs/',         icon: '⚡', priority: 1, region: 'CN' },
        { name: 'IPFSScan-CN',    url: 'https://cdn.ipfsscan.io/ipfs/',     icon: '🚀', priority: 2, region: 'CN' },
        { name: '4EVERLAND-CN',   url: 'https://4everland.io/ipfs/',        icon: '🍀', priority: 3, region: 'CN' },
        { name: 'Lighthouse-CN',  url: 'https://gateway.lighthouse.storage/ipfs/', icon: '💡', priority: 4, region: 'CN' },
        { name: 'IPFS.io-CN',     url: 'https://ipfs.io/ipfs/',             icon: '🧊', priority: 5, region: 'CN' },
        { name: 'DWeb Link-CN',   url: 'https://dweb.link/ipfs/',           icon: '🔗', priority: 6, region: 'CN' },
        { name: 'Cloudflare-IPFS',url: 'https://cloudflare-ipfs.com/ipfs/', icon: '⚡', priority: 7, region: 'CN' },
        { name: 'W3S Link-CN',    url: 'https://w3s.link/ipfs/',            icon: '💾', priority: 8, region: 'CN' },

        // 国际网关（备用）
        { name: 'Pinata',         url: 'https://gateway.pinata.cloud/ipfs/',icon: '🪅', priority: 10, region: 'INTL' },
        { name: 'NFT Storage',    url: 'https://nftstorage.link/ipfs/',     icon: '🖼️', priority: 11, region: 'INTL' },
        { name: 'Infura',         url: 'https://ipfs.infura.io/ipfs/',      icon: '🔮', priority: 12, region: 'INTL' },
        { name: 'Crust',          url: 'https://crustwebsites.net/ipfs/',   icon: '🔸', priority: 13, region: 'INTL' },
        { name: 'Jorropo',        url: 'https://ipfs.jorropo.com/ipfs/',    icon: '🌍', priority: 14, region: 'INTL' },
        { name: 'Trust IPFS',     url: 'https://trustipfs.io/ipfs/',        icon: '🛡️', priority: 15, region: 'INTL' },
        { name: 'Via IPFS',       url: 'https://via.ipfs.io/ipfs/',         icon: '🎯', priority: 16, region: 'INTL' },
        { name: 'Fleek',          url: 'https://ipfs.fleek.co/ipfs/',       icon: '⚛️', priority: 17, region: 'INTL' },
        { name: 'Web3.Storage',   url: 'https://web3.storage/ipfs/',        icon: '🌐', priority: 18, region: 'INTL' },
        { name: 'Akasha',         url: 'https://ipfs.akasha.link/ipfs/',     icon: '💫', priority: 19, region: 'INTL' },
    ],

    // 网关测试配置
    GATEWAY_TEST: {
        TIMEOUT: 10000,     // 超时时间（毫秒）
        CONCURRENT_LIMIT: 8, // 并发测速数量
        RETRY_TIMES: 1,      // 失败重试次数
        RETRY_DELAY: 1000,  // 重试延迟（毫秒）
        HIDE_UNAVAILABLE: false, // 是否隐藏不可用网关

        // 检测结果短期缓存
        CHECK_CACHE_KEY: 'cc_gateway_check_result_v1',
        CHECK_CACHE_EXPIRY: 10 * 60 * 1000, // 10分钟缓存 - 短时间内避免重复检测
        CACHE_VERSION: '2.0' // 缓存版本，用于版本控制
    },

    // 网关健康追踪配置
    GATEWAY_HEALTH: {
        HEALTH_CACHE_KEY: 'cc_gateway_health_v2',  // 健康状态缓存键（升级版本）
        HEALTH_CACHE_EXPIRY: 30 * 24 * 60 * 60 * 1000, // 30天过期

        // 网关清理规则
        CLEANUP: {
            ENABLED: true,           // 是否启用自动清理
            MAX_FAILURE_COUNT: 5,    // 最大失败次数（超过此值标记为待清理）
            MAX_CONSECUTIVE_FAILURES: 3,  // 最大连续失败次数（超过此值标记为待清理）
            MAX_UNUSED_DAYS: 30,     // 网关未使用天数（超过此天数未成功访问标记为待清理）
            MIN_HEALTH_SCORE: 10,    // 最低健康分数（低于此分数标记为待清理）
            AUTO_CLEANUP: false,     // 是否自动清理（false=仅标记，true=自动删除）
        },

        // 网关质量评分规则
        SCORING: {
            BASE_LATENCY_SCORE: 100,  // 基础延迟分数
            MAX_LATENCY: 10000,       // 最大延迟（毫秒）
            SUCCESS_BONUS: 5,         // 每次成功加分
            FAILURE_PENALTY: 10,      // 每次失败扣分
            CN_REGION_BONUS: 15,      // CN 地区加分
        }
    },

    // 文件上传配置
    UPLOAD: {
        MAX_SIZE: 1024 * 1024 * 1024,  // 最大文件大小：1GB
        MAX_SIZE_TEXT: '1GB',
        TIMEOUT: 30 * 60 * 1000           // 上传超时：30分钟
    },

    // 文件完整性验证配置
    INTEGRITY_CHECK: {
        METHOD: 'head',
        HEAD_TIMEOUT: 10000,  // HEAD 请求超时
        FULL_TIMEOUT: 30000,  // 完整下载超时
        MAX_RETRIES: 2,  // 最大重试次数
        PARALLEL_GATEWAYS: 3,
        RANGE_FALLBACK: true,
        RANGE_PARALLEL: 2,
        SKIP_OVER_SIZE_BYTES: 200 * 1024 * 1024,
    },

    // 界面配置
    UI: {
        TOAST_DURATION: 3000,  // Toast 提示显示时长（毫秒）
        AUTO_RELOAD_DELAY: 1000  // 操作完成后的自动刷新延迟
    }
};
